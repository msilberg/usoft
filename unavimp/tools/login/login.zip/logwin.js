function getScript(url, success){
	var script = document.createElement('script');
	script.src = url;
	var head = document.getElementsByTagName('head')[0],
	done = false;
	script.onload = script.onreadystatechange = function(){
		if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')){
			done = true;
			success();
			script.onload = script.onreadystatechange = null;
			head.removeChild(script);
		}
	}
	head.appendChild(script);
}
function closeLogWin(){
	jQuery("html, body").css("overflow","auto");
	jQuery("div.gs-bckgr-3254").hide();
	jQuery("div.lw-cont-3254").hide()
}
function openLogWin(){
	jQuery("html, body").animate({ scrollTop: 0 }, 0).css("overflow","hidden");
	jQuery("div.gs-bckgr-3254").show();
	jQuery("div.lw-cont-3254").css({
		"left":((window.innerWidth-jQuery("div.lw-cont-3254").width())/2)+"px",
		"top":((window.innerHeight-jQuery("div.lw-cont-3254").height())/2)+"px"
	}).show();
}
getScript('http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js', function(){
	jQuery.noConflict();
	jQuery(document).ready(function($){
		jQuery("div.opn-lw-3254").on("click", openLogWin);
		jQuery("div.cls-btn-3254").on("click", closeLogWin);
	}).keydown(function(e){ if (e.keyCode == 27){ closeLogWin() } });
});